﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace <#ClaseNameSpace>
{
    /// <summary>
    /// <#ClassTitle>
    /// </summary>
    public class <#ClassName>OR
    {
       <#ORContent>
    }
}
