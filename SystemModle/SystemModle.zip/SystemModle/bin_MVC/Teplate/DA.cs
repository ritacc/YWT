﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using DBUtility;
<#usingNamespace>

namespace <#ClaseNameSpace>
{
    /// <summary>
    /// <#ClassTitle>
    /// </summary>
    public class <#ClassName>DA : DALBase
    {
        <#daContent>
    }
}
