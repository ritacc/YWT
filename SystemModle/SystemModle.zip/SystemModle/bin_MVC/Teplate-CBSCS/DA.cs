﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using CBSCS.DBUtility;
<#usingNamespace>

namespace <#ClaseNameSpace>
{
    /// <summary>
    /// <#ClassTitle>
    /// </summary>
    public class <#ClassName>DA
    {
<#daContent>
    }
}
