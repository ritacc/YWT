﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
<#usingNamespace>

namespace <#ClaseNameSpace>
{
    /// <summary>
    /// <#ClassTitle>
    /// </summary>
    public class <#ClassName>BLL
    {
        <#daContent>
    }
}
